//Application.cpp
#include "Application.h"

namespace Qiang{
	Application::Application() {

	}


	Application::~Application() {

	}

	void Application::Run() {
		while (true);

	}
}