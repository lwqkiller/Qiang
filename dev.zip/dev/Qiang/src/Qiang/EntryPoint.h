//EntryPoint.h
#pragma once

#ifdef QIANG_PLATFORM_WINDOWS

extern Qiang::Application* Qiang::CreateApplication();

int main(int argc, char** argv) {
	auto app = Qiang::CreateApplication();
	app->Run();
	delete app;

}

#endif // QIANG_PLATFORM
